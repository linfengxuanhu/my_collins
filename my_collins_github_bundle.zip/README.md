# 我的柯林斯 v0.2
已从用户提供的 Collins COBUILD V3 MOBI 提取本地词条，内置约 3.3 万个词头。
功能：本地查词、前缀搜索、加入我的词库、来源词、学习状态、递归上下级关系。
构建：flutter pub get && flutter build apk --release


## V5 新增
- 抄词练习页
- 从个人词库取词生成练习卡
- 每个词显示释义并提供多行书写区域
- 后续可继续升级为 A4 打印 PDF、真正的描红字体和按学习状态自动出题


## V6 新增：今日抄词
- 每日从个人词库自动抽取 5/10/20 个词
- 优先抽取“未学习”词
- 显示词源（发现于哪个词）
- 每个词提供描红/抄写区域
- 可手动重新抽取


## V7 新增：COBUILD 学习卡
- 独立学习卡页面
- 释义分段/义项切换
- 自动尝试识别词性
- 例句、发现来源、学习状态
- 直接提供抄写区域


## 云端编译
项目已附带 `.github/workflows/build-apk.yml`，可通过 GitHub Actions 云端生成 release APK，无需本机 Android Studio。详细步骤见 `CLOUD_BUILD.md`。
